package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

@TeleOp(name = "meow")
public class meow extends LinearOpMode {

    // ===== CONFIG =====
    private static final int TARGET_TAG_ID = 20;

    // Turret
    private static final double SCAN_POWER = 0.3;
    private static final double kP = 0.035;
    private static final double MAX_POWER = 0.4;
    private static final double DEADZONE = 0.0;

    private boolean trackingEnabled = true;
    private boolean lastAState = false;
    private boolean scanLeft = true;
    private long lastScanSwitchTime = 0;
    private static final long SCAN_SWITCH_MS = 2000;

    // Distance filter
    private static final double DIST_ALPHA = 0.4;
    private static final double DIST_SCALE = 1.6;

    // ===== Spindex / Shooter timing =====
    private static final int SPINDEX_UP_TICKS = -116;
    private static final double SPINDEX_START_SEC = 2.0;
    private static final double TOTAL_FIRE_TIME_SEC = 6.0;

    // Hardware
    private Limelight3A limelight;
    private CRServo turretLeft, turretRight;
    private DcMotor shooterMotor;
    private DcMotor spindex;

    // Distance tracking
    private double rawDistance = 0.0;
    private double filteredDistance = 1.0;

    // ===== Firing sequence state =====
    private boolean firingSequenceActive = false;
    private double firingStartTime = 0.0;
    private boolean lbWasPressed = false;

    @Override
    public void runOpMode() {

        // Hardware map
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        turretLeft = hardwareMap.get(CRServo.class, "servo1");
        turretRight = hardwareMap.get(CRServo.class, "servo2");
        shooterMotor = hardwareMap.get(DcMotor.class, "motor3");
        spindex = hardwareMap.get(DcMotor.class, "motor7");

        spindex.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        spindex.setTargetPosition(0);
        spindex.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        spindex.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        spindex.setPower(0.5);

        limelight.pipelineSwitch(0);
        limelight.start();

        telemetry.addLine("Top Assembly Ready");
        telemetry.update();

        waitForStart();

        while (opModeIsActive()) {

            // ===== Toggle turret tracking =====
            boolean aPressed = gamepad1.a;
            if (aPressed && !lastAState) {
                trackingEnabled = !trackingEnabled;
            }
            lastAState = aPressed;

            // ===== Limelight detection =====
            boolean tagVisible = false;
            double tx = 0.0;

            LLResult result = limelight.getLatestResult();
            if (result != null && result.isValid()) {
                for (LLResultTypes.FiducialResult fid : result.getFiducialResults()) {
                    if (fid.getFiducialId() == TARGET_TAG_ID) {
                        tagVisible = true;
                        tx = fid.getTargetXDegrees();

                        Pose3D pose = fid.getTargetPoseCameraSpace();
                        double x = pose.getPosition().x;
                        double y = pose.getPosition().y;
                        double z = pose.getPosition().z;

                        rawDistance = Math.sqrt(x*x + y*y + z*z);
                        double corrected = rawDistance * DIST_SCALE;
                        filteredDistance =
                                (1 - DIST_ALPHA) * filteredDistance + DIST_ALPHA * corrected;
                        break;
                    }
                }
            }

            // ===== Turret control =====
            double turretPower = 0.0;
            if (trackingEnabled) {
                if (tagVisible) {
                    if (Math.abs(tx) > DEADZONE) {
                        turretPower = Range.clip(kP * tx, -MAX_POWER, MAX_POWER);
                    }
                } else {
                    long now = System.currentTimeMillis();
                    if (now - lastScanSwitchTime > SCAN_SWITCH_MS) {
                        scanLeft = !scanLeft;
                        lastScanSwitchTime = now;
                    }
                    turretPower = scanLeft ? -SCAN_POWER : SCAN_POWER;
                }
            }
            turretLeft.setPower(turretPower);
            turretRight.setPower(turretPower);

            // ===== Fire sequence (LEFT BUMPER) =====
            if (gamepad1.left_bumper && !lbWasPressed && !firingSequenceActive) {
                firingSequenceActive = true;
                firingStartTime = getRuntime();
            }
            lbWasPressed = gamepad1.left_bumper;

            // ===== Sequence timing =====
            if (firingSequenceActive) {
                double elapsed = getRuntime() - firingStartTime;

                // Shooter runs immediately for full 6s
                shooterMotor.setPower(
                        getShooterPowerFromDistance(filteredDistance));

                // Spindex starts AFTER 2 seconds
                if (elapsed >= SPINDEX_START_SEC) {
                    spindex.setTargetPosition(SPINDEX_UP_TICKS);
                }

                // Stop BOTH at 6 seconds
                if (elapsed >= TOTAL_FIRE_TIME_SEC) {
                    shooterMotor.setPower(0);
                    spindex.setTargetPosition(0);
                    firingSequenceActive = false;
                }
            } else {
                shooterMotor.setPower(0);
            }

            // ===== Telemetry =====
            telemetry.addData("Tracking", trackingEnabled);
            telemetry.addData("Tag Visible", tagVisible);
            telemetry.addData("tx", tx);
            telemetry.addData("Distance (m)", filteredDistance);
            telemetry.addData("Firing Active", firingSequenceActive);
            telemetry.addData("Spindex Pos", spindex.getCurrentPosition());
            telemetry.addData("Shooter Power", shooterMotor.getPower());
            telemetry.update();

            idle();
        }
    }

    // ===== Shooter lookup interpolation =====
    private double getShooterPowerFromDistance(double distanceMeters) {

        double[][] SHOOTER_TABLE = {
                {0.75, 0.60}, {1.00, 0.68}, {1.25, 0.76}, {1.50, 0.84},
                {1.75, 0.92}, {2.00, 1.00}, {2.25, 1.00}, {2.50, 1.00},
                {2.75, 1.00}, {3.00, 1.00}
        };

        if (distanceMeters <= SHOOTER_TABLE[0][0]) return SHOOTER_TABLE[0][1];
        if (distanceMeters >= SHOOTER_TABLE[SHOOTER_TABLE.length - 1][0])
            return SHOOTER_TABLE[SHOOTER_TABLE.length - 1][1];

        for (int i = 0; i < SHOOTER_TABLE.length - 1; i++) {
            double d0 = SHOOTER_TABLE[i][0];
            double d1 = SHOOTER_TABLE[i + 1][0];
            if (distanceMeters >= d0 && distanceMeters <= d1) {
                double p0 = SHOOTER_TABLE[i][1];
                double p1 = SHOOTER_TABLE[i + 1][1];
                double t = (distanceMeters - d0) / (d1 - d0);
                return Range.clip(p0 + (p1 - p0) * t, 0, 1.0);
            }
        }
        return 0;
    }
}
