package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.Range;

import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;

import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

@TeleOp
public class IHATESTEMTRONS extends LinearOpMode {

    // -----------------
    // Hardware
    // -----------------
    DcMotor flDrive, frDrive, rlDrive, rrDrive;
    DcMotor intake, shooterMotor, transfer;
    DcMotorEx armMotor;
    CRServo turretLeft, turretRight;
    Servo hoodServo;
    Limelight3A limelight;
    double turningPower = 0;
    @Override
    public void runOpMode() {

        // -----------------
        // Hardware Mapping
        // -----------------
        flDrive = hardwareMap.dcMotor.get("motor4");
        frDrive = hardwareMap.dcMotor.get("motor0");
        rlDrive = hardwareMap.dcMotor.get("motor5");
        rrDrive = hardwareMap.dcMotor.get("motor1");
        intake = hardwareMap.dcMotor.get("motor2");
        intake.setDirection(DcMotor.Direction.REVERSE);
        armMotor = hardwareMap.get(DcMotorEx.class, "motor7");
        shooterMotor = hardwareMap.get(DcMotor.class, "motor3");
        transfer = hardwareMap.get(DcMotor.class, "motor6");
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        turretLeft = hardwareMap.get(CRServo.class, "servo6");
        turretRight = hardwareMap.get(CRServo.class, "servo5");
        hoodServo = hardwareMap.get(Servo.class, "servo4");

        // -----------------
        // Motor Setup
        // -----------------
        flDrive.setDirection(DcMotorSimple.Direction.REVERSE);
        frDrive.setDirection(DcMotorSimple.Direction.REVERSE);

        //armMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        //armMotor.setTargetPosition(0);
        //armMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        //((DcMotorEx) armMotor).setVelocity(650);
    
        transfer.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        transfer.setTargetPosition(0);
        transfer.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        limelight.pipelineSwitch(0);
        limelight.start();
        boolean intakeOn = false, yPressedLast = false;
        boolean shooterOn = false;
        waitForStart();

        while (opModeIsActive()) {

            // -----------------
            // Drivetrain
            // -----------------
            double y = gamepad1.left_stick_y;
            double x = -gamepad1.left_stick_x;
            double rx = -gamepad1.right_stick_x;

            double fl = y + x + rx;
            double fr = y - x - rx;
            double rl = y - x + rx;
            double rr = y + x - rx;

            double max = Math.max(Math.max(Math.abs(fl), Math.abs(fr)),
                                  Math.max(Math.abs(rl), Math.abs(rr)));

            if (max > 1.0) {
                fl /= max; fr /= max; rl /= max; rr /= max;
            }

            flDrive.setPower(fl);
            frDrive.setPower(fr);
            rlDrive.setPower(rl);
            rrDrive.setPower(rr);

            // -----------------
            // Intake
            // -----------------
            if (gamepad1.y && !yPressedLast)
                intakeOn = !intakeOn;
            yPressedLast = gamepad1.y;
            intake.setPower(intakeOn ? 1.0 : 0.0);
            if (gamepad1.dpad_up) {
                armMotor.setPower(.5);
            }
            if (!gamepad1.dpad_up && !gamepad1.dpad_down) {
                armMotor.setPower(0);
            }
            if (gamepad1.dpad_down) {
                armMotor.setPower(-.5);
            }
            if (gamepad1.right_bumper) {
                if (!shooterOn) {
                shooterMotor.setPower(1);
                shooterOn = true;
                }else {
                    shooterOn = false;
                    shooterMotor.setPower(0);
                }
            }
            LLResult result = limelight.getLatestResult();
            if (result != null && result.isValid()) {
                double error = result.getTx();
                if (Math.abs(error) > 0) {
                turningPower = error *.02;
                }
            } else {
                turningPower = 0;
            }
            turretRight.setPower(turningPower);
            turretLeft.setPower(turningPower);
            // -----------------
            // Telemetry
            // -----------------
            telemetry.addData("Spindexer Pos:", armMotor.getCurrentPosition());
            telemetry.addData("Does I see?:", result.isValid());
            telemetry.addData("Turning Pow:", turningPower);
            telemetry.update();
        }
    }
}